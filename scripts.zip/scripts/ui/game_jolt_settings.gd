extends Control

func _ready() -> void:
	Autoload.load_data()
	$MarginContainer/VBoxContainer/HBoxContainer/Username.text = Autoload.data.username
	$MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text = Autoload.data.usertoken
	$MarginContainer/VBoxContainer/HBoxContainer3/CheckButton.button_pressed = Autoload.data.auto_auth
	GameJolt.users_auth_completed.connect(check_auth)
	GameJolt.users_auth()

func _on_back_pressed() -> void:
	Autoload.click()
	GameJolt.set_user_name($MarginContainer/VBoxContainer/HBoxContainer/Username.text)
	GameJolt.set_user_token($MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text)
	Autoload.data.auto_auth = $MarginContainer/VBoxContainer/HBoxContainer3/CheckButton.button_pressed
	Autoload.data.username = $MarginContainer/VBoxContainer/HBoxContainer/Username.text
	Autoload.data.usertoken = $MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text
	Autoload.save_data()
	get_tree().change_scene_to_file("res://scenes/ui/main_menu.tscn")
	
func _on_login_pressed() -> void:
	Autoload.click()
	GameJolt.set_user_name($MarginContainer/VBoxContainer/HBoxContainer/Username.text)
	GameJolt.set_user_token($MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text)
	Autoload.data.auto_auth = $MarginContainer/VBoxContainer/HBoxContainer3/CheckButton.button_pressed
	Autoload.data.username = $MarginContainer/VBoxContainer/HBoxContainer/Username.text
	Autoload.data.usertoken = $MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text
	Autoload.save_data()
	GameJolt.users_auth()

func check_auth(response) -> void:
	print("[AUTH RESPONSE]: " + str(response))
	if response.success == "true":
		$MarginContainer/VBoxContainer/Status.text = "SGJ_LOGIN_ST"
		$MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text = GameJolt.get_user_token()
		$MarginContainer/VBoxContainer/HBoxContainer/Username.text = GameJolt.get_user_name()
		Autoload.data.username = GameJolt.get_user_name()
		Autoload.data.usertoken = GameJolt.get_user_token()
		Autoload.save_data(Autoload.data.duplicate())
	else:
		$MarginContainer/VBoxContainer/Status.text = TranslationServer.translate("SGJ_LOGER_ST") + " " + response.message
		print(Autoload.data)

func _on_check_button_pressed() -> void:
	Autoload.click()

func _on_tab_container_tab_changed(_tab: int) -> void:
	if Autoload.data.auto_auth:
		Autoload.data.username = $MarginContainer/VBoxContainer/HBoxContainer/Username.text
		Autoload.data.usertoken = $MarginContainer/VBoxContainer/HBoxContainer2/GameToken.text
	Autoload.save_data()

func _on_username_text_changed(new_text: String) -> void:
	Autoload.data.username = new_text

func _on_game_token_text_changed(new_text: String) -> void:
	Autoload.data.usertoken = new_text
